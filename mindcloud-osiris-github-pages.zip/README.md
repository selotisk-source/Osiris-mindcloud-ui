# MindCloud × Osiris UI

GitHub Pages-ready static operator UI prototype for the MindCloud / Osiris architecture.

## Current state
- PAPER / SANDBOX
- LIVE LOCKED
- Camera switching and local coverage visualization
- Model-based blind-spot indicators (not proof of events)
- Reference assets included

## Deploy
GitHub Pages can deploy this repository using the included `.github/workflows/pages.yml` workflow.

Expected Pages URL:
`https://selotisk-source.github.io/Osiris-mindcloud-ui/`

## Architecture note
The UI is the MindCloud control/observation layer. Osiris is treated as a backend/adapter concept; no live surveillance or production camera feed is connected by this static prototype.
